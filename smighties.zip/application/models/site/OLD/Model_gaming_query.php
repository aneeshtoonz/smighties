<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_gaming_query extends MY_Model
{

    protected $table = TBL_COURSES_GAMING_QUERY;
    protected $primary_key = 'id';

}
