<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_afma_course_query extends MY_Model
{

    protected $table = TBL_AFMA_COURSE;
    protected $primary_key = 'id';

}
