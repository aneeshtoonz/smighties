http_path = "/"
css_dir = "css"
sass_dir = "scss"
images_dir = "img"
javascripts_dir = "js"

output_style = :compact # :expanded or :nested or :compact or :compressed

relative_assets = true

line_comments = false