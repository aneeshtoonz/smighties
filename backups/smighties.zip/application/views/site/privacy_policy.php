<div class="page-wrapper">

      <div class="container-fluidic container-tv-header">

          <div class="container">

              <?php $this->load->view('site/includes/menu');?>

              <div class="clearfix"></div>

              <div class="page-title">
                <h1 class="grd-txt">Privacy Policy</h1>
              </div>

              <div class="clearfix"></div>

              <div class="block row mt-md blog-content">

                  <div class="col-lg-12">
                    <p><a href="#">Ferdinand</a> is directed by Blue Sky stalwart Carlos Saldanha, who was a co-director on the studio’s first feature Ice Age and has since directed Rio and Ice Age: The Meltdown on his own.</p>
                    <h2>COPPA Compatible</h2>
                    <p><a href="#">Ferdinand</a> is directed by Blue Sky stalwart Carlos Saldanha, who was a co-director on the studio’s first feature Ice Age and has since directed Rio and Ice Age: The Meltdown on his own.</p>
                  </div>

              </div>

              <div class="clearfix"></div>

          </div>

      </div>

      <?php $this->load->view('site/includes/footer-sm');?>

    </div>
