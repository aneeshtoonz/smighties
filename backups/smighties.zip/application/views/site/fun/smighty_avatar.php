<div class="page-wrapper">

      <div class="container-fluidic container-tv-header">

          <div class="container">

              <?php $this->load->view('site/includes/menu');?>

              <div class="clearfix"></div>

              <div class="page-title">
                <h1 class="grd-txt">Create a Smighty Avatar</h1>
                <h2>Create and download facebook avatar</h2>
              </div>

              <div class="clearfix"></div>

              <div class="menu-tabs visible-lg">

                  <a href="<?php echo HOST_URL?>/games">
                    <i class="ion-play"></i> Games
                  </a>
                  <a href="<?php echo HOST_URL?>/smighty-friend">
                      <i class="ion-music-note"></i> Smighty Friend
                  </a>
                  <a href="<?php echo HOST_URL?>/facebook-smighty-badge" class="active">
                    <span class="left"></span>
                    <span class="middle"><i class="ion-music-note"></i> Facebook Badge</span>
                    <span class="right"></span>

                  </a>

              </div>

              <div class="clearfix"></div>

              <div class="block row mt-md blog-content text-left flex-wrapper">

                  <div class="col-lg-8 col-xs-10 col-sm-12 nofloats inline smfriend-wrapper mt-lg">

                      <div class="pull-left smfriend-image">
                          <img src="images/smighties-dummy-image.png" alt="" />
                      </div>

                      <div class="sm-friend-info text-left">
                          <h2 class="grd-txt mb-md">Sign in with facebook</h2>
                          <p>Mighty Smighties is Card Game FUN for EVERYONE! Play with your friends, collect all the cards!</p>
                          <button type="button" class="fb-button mt-md">
                            <span><i class="ion-social-facebook"></i></span>
                            Login with facebook
                          </button>

                      </div>

                  </div>

                  <div class="clearfix"></div>

              </div>

              <div class="clearfix"></div>

          </div>

      </div>

      <?php $this->load->view('site/includes/footer-sm');?>

    </div>
