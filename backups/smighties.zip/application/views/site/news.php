<div class="page-wrapper">

      <div class="container-fluidic container-tv-header">

          <div class="container">

              <?php $this->load->view('site/includes/menu');?>

              <div class="clearfix"></div>

              <div class="page-title">
                <h1 class="grd-txt">NEWS ROOM</h1>
                <h2>See the latest news updates from Smighties town.</h2>
              </div>

              <div class="clearfix"></div>

              <div class="block row mt-lg">

                  <div class="row news-row">

                    <div class="col-lg-4 news-item mb-lg col-xs-12 col-md-12 col-sm-12">
                        <div class="col-lg-12 col-xs-10 col-sm-10 col-md-10">
                            <div class="inline">
                              <img src="images/news1.jpg" alt="" />
                              <div class="clearfix"></div>
                              <div class="title"> Watch the Trailer For Blue Sky Studios’ ‘Ferdinand’</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 news-item mb-lg col-xs-12 col-md-12 col-sm-12">
                      <div class="col-lg-12 col-xs-10 col-sm-10 col-md-10">
                          <div class="inline">
                              <img src="images/news2.jpg" alt="" />
                              <div class="clearfix"></div>
                              <div class="title"> ‘Hey Duggee’ Creator Grant Orchard On Creating</div>
                          </div>
                      </div>
                    </div>

                    <div class="col-lg-4 news-item mb-lg col-xs-12 col-md-12 col-sm-12">
                      <div class="col-lg-12 col-xs-10 col-sm-10 col-md-10">
                          <div class="inline">
                              <img src="images/news1.jpg" alt="" />
                              <div class="clearfix"></div>
                              <div class="title"> Watch the Trailer For Blue Sky Studios’ ‘Ferdinand’</div>
                          </div>
                      </div>
                    </div>

                    <div class="col-lg-4 news-item col-xs-12 col-md-12 col-sm-12">
                        <div class="col-lg-12 col-xs-10 col-sm-10 col-md-10">
                            <div class="inline">
                                <img src="images/news1.jpg" alt="" />
                                <div class="clearfix"></div>
                                <div class="title"> Watch the Trailer For Blue Sky Studios’ ‘Ferdinand’</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 news-item col-xs-12 col-md-12 col-sm-12">
                      <div class="col-lg-12 col-xs-10 col-sm-10 col-md-10">
                          <div class="inline">
                              <img src="images/news2.jpg" alt="" />
                              <div class="clearfix"></div>
                              <div class="title"> ‘Hey Duggee’ Creator Grant Orchard On Creating</div>
                          </div>
                      </div>
                    </div>

                    <div class="col-lg-4 news-item col-xs-12 col-md-12 col-sm-12">
                      <div class="col-lg-12 col-xs-10 col-sm-10 col-md-10">
                          <div class="inline">
                              <img src="images/news1.jpg" alt="" />
                              <div class="clearfix"></div>
                              <div class="title"> Watch the Trailer For Blue Sky Studios’ ‘Ferdinand’</div>
                          </div>
                      </div>
                    </div>

                  </div>

              </div>

              <div class="clearfix"></div>

          </div>

      </div>

      <?php $this->load->view('site/includes/footer-sm');?>

    </div>
