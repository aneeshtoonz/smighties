<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_competitions extends MY_Model
{

    protected $table = TBL_COMPETITIONS;
    protected $primary_key = 'id';

}
