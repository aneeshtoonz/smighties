<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

		public function __construct() {

			 parent::__construct();

			 $this->data['meta_keywords'] = '$this->meta_keywords'; // Requrioed
			 $this->data['meta_description'] = '$this->meta_description'; //Required

			 //  $this->output->cache(20);
		}

		public function index() {

			 $this->data['content'] = SITE_VIEWS . '/home';
			 $this->data['current_item'] = 'home';
			 $this->data['class__styles'] = 'body';

			//  $this->data['meta_title'] = $this->data['page_data']->meta_title;
			//  $this->data['meta_keywords'] = $this->data['page_data']->meta_keywords; // Requrioed
			//  $this->data['meta_description'] = $this->data['page_data']->meta_description; //Required

			 $this->load->view($this->layout, $this->data);

		}

		public function about() {

			 $this->data['content'] = SITE_VIEWS . '/about';
			 $this->data['current_item'] = 'about';
			 $this->data['class__styles'] = 'container-about';

			//  $this->data['meta_title'] = $this->data['page_data']->meta_title;
			//  $this->data['meta_keywords'] = $this->data['page_data']->meta_keywords; // Requrioed
			//  $this->data['meta_description'] = $this->data['page_data']->meta_description; //Required

			 $this->load->view($this->layout, $this->data);

		}

		public function contact() {

			 $this->data['content'] = SITE_VIEWS . '/contact';
			 $this->data['current_item'] = 'contact';
			 $this->data['class__styles'] = 'container-about';

			//  $this->data['meta_title'] = $this->data['page_data']->meta_title;
			//  $this->data['meta_keywords'] = $this->data['page_data']->meta_keywords; // Requrioed
			//  $this->data['meta_description'] = $this->data['page_data']->meta_description; //Required

			 $this->load->view($this->layout, $this->data);

		}

		public function privacy() {

			 $this->data['content'] = SITE_VIEWS . '/privacy_policy';
			 $this->data['current_item'] = 'privacy';
			 $this->data['class__styles'] = 'container-about';

			//  $this->data['meta_title'] = $this->data['page_data']->meta_title;
			//  $this->data['meta_keywords'] = $this->data['page_data']->meta_keywords; // Requrioed
			//  $this->data['meta_description'] = $this->data['page_data']->meta_description; //Required

			 $this->load->view($this->layout, $this->data);

		}

		public function terms() {

			 $this->data['content'] = SITE_VIEWS . '/terms';
			 $this->data['current_item'] = 'terms';
			 $this->data['class__styles'] = 'container-about';

			//  $this->data['meta_title'] = $this->data['page_data']->meta_title;
			//  $this->data['meta_keywords'] = $this->data['page_data']->meta_keywords; // Requrioed
			//  $this->data['meta_description'] = $this->data['page_data']->meta_description; //Required

			 $this->load->view($this->layout, $this->data);

		}

		public function pedia() {

			 $this->data['content'] = SITE_VIEWS . '/pedia/index';
			 $this->data['current_item'] = 'pedia';
			 $this->data['class__styles'] = 'container-tv';

			//  $this->data['meta_title'] = $this->data['page_data']->meta_title;
			//  $this->data['meta_keywords'] = $this->data['page_data']->meta_keywords; // Requrioed
			//  $this->data['meta_description'] = $this->data['page_data']->meta_description; //Required

			 $this->load->view($this->layout, $this->data);

		}

		public function villains() {

			 $this->data['content'] = SITE_VIEWS . '/pedia/villains';
			 $this->data['current_item'] = 'villains';
			 $this->data['class__styles'] = 'container-tv';

			//  $this->data['meta_title'] = $this->data['page_data']->meta_title;
			//  $this->data['meta_keywords'] = $this->data['page_data']->meta_keywords; // Requrioed
			//  $this->data['meta_description'] = $this->data['page_data']->meta_description; //Required

			 $this->load->view($this->layout, $this->data);

		}

}
