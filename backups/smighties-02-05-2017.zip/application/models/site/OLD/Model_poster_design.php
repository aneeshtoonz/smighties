<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_poster_design extends MY_Model {

    protected $table = TBL_POSTER_DESIGN;
    protected $primary_key = 'id';

}
