<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_testimonials extends MY_Model {

    protected $table = TBL_TESTIMONIALS;
    protected $primary_key = 'id';

}
