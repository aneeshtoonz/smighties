<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_course extends MY_Model {

    protected $table = TBL_COURSES;
    protected $primary_key = 'id';

}
