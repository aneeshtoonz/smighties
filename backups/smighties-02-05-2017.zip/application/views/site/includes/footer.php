<div class="container footer home-footer">

    <div class="pull-left footer-links visible-lg visible-md">
        <a href="<?php echo HOST_URL?>/privacy-policy" class="coppa-lg">PRIVACY POLICY</a>
        <a href="<?php echo HOST_URL?>/terms-of-use" class="coppa-lg">TERMS</a>
        <a href="<?php echo HOST_URL?>/news">NEWS ROOM</a>
        <a href="<?php echo HOST_URL?>/blog">BLOG</a>
        <a href="<?php echo HOST_URL?>/contact">CONTACT</a>
    </div>

    <div class="pull-right footer-copyright">
       <a href="<?php echo HOST_URL?>/aboutus">HEROTAINMENT, LLC</a> .  COPYRIGHT &copy; <?php echo date('Y')?>
    </div>

</div>
