<div class="page-wrapper">

      <div class="container-fluidic container-tv-header">

          <div class="container">

              <?php $this->load->view('site/includes/menu');?>

              <div class="clearfix"></div>

              <div class="page-title">
                <h1 class="grd-txt">Watch the Trailer For ‘Ferdinand’</h1>
                <h2>Posted on 29 Mar by Administrator</h2>
              </div>

              <div class="clearfix"></div>

              <div class="block row mt-md blog-content">

                  <div class="col-lg-10 col-xs-12 col-md-12 col-sm-12">
                    <img src="<?php echo IMG_PATH?>/news-hd.jpg" alt="" class="img-responsive"/>
                    <h1>Watch the Trailer For ‘Ferdinand’</h1>
                    <p><a href="#">Ferdinand</a> is directed by Blue Sky stalwart Carlos Saldanha, who was a co-director on the studio’s first feature Ice Age and has since directed Rio and Ice Age: The Meltdown on his own.</p>

                  </div>

              </div>

              <div class="clearfix"></div>

          </div>

      </div>

      <?php $this->load->view('site/includes/footer-sm');?>

    </div>
