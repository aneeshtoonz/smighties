<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Model_cms extends MY_Model
{

    protected $table = TBL_CMS;
    protected $primary_key = 'id';

}
