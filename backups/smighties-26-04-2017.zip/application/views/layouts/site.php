<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Smighties | Small but mightiest</title>
    <meta name="keywords" content="Smighties | Small but mightiest" />
    <meta name="description" content="Smighties | Small but mightiest" />
    <link href="" rel="icon" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" />
    <link rel="stylesheet" href="<?php echo CSS_PATH?>/styles.css"/>
    <link rel="stylesheet" href="<?php echo CSS_PATH?>/bootstrap.min.css"/>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="<?php echo JS_PATH?>/bootstrap.min.js"></script>
    <script src="<?php echo JS_PATH?>/response.min.js"></script>

    <script type="text/javascript">

        (function($, R) {

                R.ready(function() {
                    console.log('R.deviceW() = ' + R.deviceW()
                  + '<br>R.deviceH() = ' + R.deviceH()
                  + '<br>R.deviceMax() = ' + R.deviceMax()
                  + '<br>R.deviceMin() = ' + R.deviceMin()
                  + '<br>R.dpr() = ' + R.dpr());
                });

                $(document).on('click','.play-intro-video', function(e){

                    var container = $('#container-home');
                    e.preventDefault();
                    $('.video-container').removeClass('hidden');
                    container.css('background', "transparent");
                    return false;

                });

          }(this.jQuery, this.Response));

    </script>

</head>

<body class="<?php echo $class__styles?>" data-responsejs='{
  "create": [{
    "prop": "width",
    "prefix": "min-width- r src",
    "breakpoints": [0, 320, 481, 641, 961, 1025]
  }]
}'>

  <?php $this->load->view($content)?>

</body>
</html>
