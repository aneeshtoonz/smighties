<ol class="breadcrumb">
<li><a href="<?php echo HOST_URL . "/" . ADMIN_URL?>/Dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
<li class="active"><?php echo $this->router->fetch_class();?></li>
</ol>
