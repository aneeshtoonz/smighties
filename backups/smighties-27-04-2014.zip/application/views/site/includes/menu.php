<header>

    <a href="<?php echo HOST_URL?>/" class="logo pull-left"></a>

    <nav class="main-nav pull-right visible-lg visible-md">
       <ul>
          <li><a href="<?php echo HOST_URL?>/smighties-tv">SMIGHTIES TV</a></li>
          <li><a href="<?php echo HOST_URL?>/games">FUN SPACE</a></li>
          <li><a href="<?php echo HOST_URL?>/smightypedia">SMIGHTYPEDIA</a></li>
          <li><a href="<?php echo HOST_URL?>/downloads/wallpapers">GOODIES</a></li>
          <li><a href="<?php echo HOST_URL?>/parents">PARENTS</a></li>
       </ul>
    </nav>

    <div class="sm-menu visible-xs visible-sm" data-toggle="modal" data-target="#collapsbleMenu">
        <img src="<?php echo IMG_PATH?>/more.png" alt="" />
    </div>

</header>
